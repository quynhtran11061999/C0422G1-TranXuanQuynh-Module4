package com.codegym;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class C04gSpringWebServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(C04gSpringWebServiceApplication.class, args);
    }

}
